/*
 * native_Feature_detector.cpp
 *
 *  Created on: 2014/12/02
 *      Author: rm0426
 */

#include <native_feature_detect_jni.hpp>
#include <opencv2/features2d/features2d.hpp>
//#include <opencv2/nonfree/features2d.hpp>
//#include <opencv2/nonfree/nonfree.hpp> //SURF, SIFTを実行する際に必要だが、Android用のSDKでは存在しない。商用ライセンスの問題らしい。
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <string>
#include <vector>

#include <android/log.h>

#define LOG_TAG "Native_Feature_Detect"
#define LOGD(...) ((void)__android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__))

using namespace std;
using namespace cv;


/** 変数宣言 **/
const string mSpported_features[] = {"ORB"}; //今回はORBのみサポートする

cv::Ptr<cv::FeatureDetector> detector;
vector<KeyPoint> keypoints;

//cv::Ptr<DescriptorExtractor> extractor;
//Mat descriptors;
Mat blackImg;

/**
 * 初期化、特徴点抽出クラスに何の手法を使うかなどを指定
 */
JNIEXPORT void JNICALL
Java_moverio_opencv_sample_app_CVFeatureDetector_initNativeFeatureDetect
(JNIEnv * jenv, jclass clazz, jint width, jint height, jint method, jint threshold){

	string mode = mSpported_features[0];//今回は何が渡されてきてもORBのみの動作とするため
	detector  	= FeatureDetector::create(mode);
	//extractor = escriptorExtractor::create(mode);
	blackImg 	= Mat::zeros(cv::Size(width,height), CV_8UC4);
}

/**
 * Mat, Ptr型は自動でGBされるので、明示的にメモリサイズを指定して確保していなければ解放する必要なし
 */
JNIEXPORT void JNICALL
Java_moverio_opencv_sample_app_CVFeatureDetector_releaseNativeFeatureDetect
(JNIEnv * jenv, jclass clazz) {
	//検出結果を空っぽにする。
	detector->empty();
	//extractor->empty();
	keypoints.clear();
	blackImg.release();
}

/**
 * 特徴点抽出実行 <br>
 * isBlackbackの値によって、背景画を黒で塗りつぶすか、グレー画像にするかを選択できる
 */
JNIEXPORT void JNICALL
Java_moverio_opencv_sample_app_CVFeatureDetector_execNativeFeatureDetect
(JNIEnv * jenv, jclass clazz, jlong srcGrayImgAdd, jlong dstColorImgAdd, jboolean isBlackBack){

	if(srcGrayImgAdd == 0x0 || dstColorImgAdd == 0x0) {
		LOGD("dstColorImgAdd or srcImgAdd is null. Can't start");
	} else {
		LOGD("execNativeFeatureDetect");
		keypoints.empty();
		detector->detect((*((Mat*)srcGrayImgAdd)), keypoints);
//		extractor->compute((*((Mat*)srcGrayImgAdd)), keypoints, descriptors);
		if(isBlackBack) {
			drawKeypoints(blackImg, keypoints, (*((Mat*)dstColorImgAdd)),
					Scalar::all(-1), DrawMatchesFlags::DEFAULT );
		} else {
			drawKeypoints((*((Mat*)srcGrayImgAdd)), keypoints, (*((Mat*)dstColorImgAdd)),
					Scalar::all(-1), DrawMatchesFlags::DEFAULT );
		}
	}
}



