package moverio.opencv.sample.app;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.objdetect.CascadeClassifier;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;


/**
 * 顔検出用のクラス <br>
 * 基本的にはOpenCVの顔検出用のサンプルから移植している。<p>
 * 
 * 参照元: OpenCV-2.4.9-android-sdk/samples/face-detection/jni/DetectionBasedTracker.h, cpp
 * */
public class CVFaceDetector {

	private static final String TAG 					= "CVFaceDetector";
	private static final String LOG_CASCADE_LOAD		= "cascacde classifier load";
	private static final String LOG_CASCADE_LOAD_FROM	= LOG_CASCADE_LOAD+" from ";
	private static final String LOG_CASCADE_LOAD_FAIL	= LOG_CASCADE_LOAD+" failed";
	private static final String LOG_LOAD_EXEPTION 		= "Failed to load cascade. Exception thrown: ";

	private static final String DIR_CASCADE				= "cascade";
	private static final String LIB_FACE_XML 			= "lbpcascade_frontalface.xml";

	private static final Scalar	FACE_RECT_COLOR     	= new Scalar(0, 255, 0, 255);
	private static final int 	INIT_FACE_SIZE			= 0;
    public static final int		JAVA_DETECTOR    	   	= 0;
    public static final int		NATIVE_DETECTOR     	= 1;

	private static final int 	BUFFER_SIZE 			= 4096;
	private static final int 	BYTE_READ_ERROR 		= -1;

	private long 				mNativeObj 				= 0;	
	private CascadeClassifier	mJavaDetector;
	private File				mCascadeFile;
	private float               mRelativeFaceSize   	= 0.2f;
	private int                 mAbsoluteFaceSize   	= 0;
	private int 				mCameraWidth;
	private int					mCameraHeight;

	private static native long nativeCreateObject(String cascadeName, int minFaceSize);
	private static native void nativeDestroyObject(long thiz);
//	private static native void nativeStart(long thiz);
//	private static native void nativeStop(long thiz);
	private static native void nativeSetFaceSize(long thiz, int size);
	private static native void nativeDetect(long thiz, long inputImage, long faces);

	public CVFaceDetector(Context ctxt, int camera_width, int camera_height) {
		try {
			// load cascade file from application resources
			InputStream is = ctxt.getResources().openRawResource(R.raw.lbpcascade_frontalface);
			File cascadeDir = ctxt.getDir(DIR_CASCADE, Context.MODE_PRIVATE);
			mCascadeFile = new File(cascadeDir, LIB_FACE_XML);
			FileOutputStream os = new FileOutputStream(mCascadeFile);

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead;
			while ((bytesRead = is.read(buffer)) != BYTE_READ_ERROR) {
				os.write(buffer, 0, bytesRead);
			}
			is.close();
			os.close();

			String path = mCascadeFile.getAbsolutePath();
			mJavaDetector = new CascadeClassifier(path);
			if (mJavaDetector.empty()) {
				Log.e(TAG, LOG_CASCADE_LOAD_FAIL);
				mJavaDetector = null;
			} else {
				Log.i(TAG,  LOG_CASCADE_LOAD_FROM + path);
			}
			mNativeObj = nativeCreateObject(path, INIT_FACE_SIZE);
			cascadeDir.delete();

		} catch (IOException e) { 
			e.printStackTrace();
			Log.e(TAG,  LOG_LOAD_EXEPTION + e);
		}
		
		mCameraWidth  		= camera_width;
		mCameraHeight 		= camera_height; 
        mAbsoluteFaceSize 	= 0;
	}
	
	
	public void execFaceDetection(Mat grayImg, Mat dstImg) {
        if (mAbsoluteFaceSize == 0) {
            int height = grayImg.rows();
            if (Math.round(height * mRelativeFaceSize) > 0) {
                mAbsoluteFaceSize = Math.round(height * mRelativeFaceSize);
            }
            setMinFaceSize(mAbsoluteFaceSize);
        }
        MatOfRect faces = new MatOfRect();
        detect(grayImg, faces);
        
        Rect[] facesArray = faces.toArray();
        for (int i = 0; i < facesArray.length; i++) {
            Core.rectangle(dstImg, facesArray[i].tl(), facesArray[i].br(), FACE_RECT_COLOR, 3);
        }
	}

//	private void start() {
//		nativeStart(mNativeObj);
//	}
//
//	private void stop() {
//		nativeStop(mNativeObj);
//	}

	private void setMinFaceSize(int size) {
		nativeSetFaceSize(mNativeObj, size);
	}

	private void detect(Mat imageGray, MatOfRect faces) {
		nativeDetect(mNativeObj, imageGray.getNativeObjAddr(), faces.getNativeObjAddr());
	}

	public void release() {
		nativeDestroyObject(mNativeObj);
		mNativeObj = 0;
	}
	
}
