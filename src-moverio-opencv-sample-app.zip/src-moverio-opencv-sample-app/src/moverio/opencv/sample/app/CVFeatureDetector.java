package moverio.opencv.sample.app;

import java.util.ArrayList;
import java.util.List;

import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfKeyPoint;
import org.opencv.features2d.DescriptorExtractor;
//import org.opencv.features2d.DescriptorMatcher;
import org.opencv.features2d.FeatureDetector;
import org.opencv.features2d.Features2d;
import android.util.Log;

/**
 * 特徴点抽出を行う際に用いるクラス <br>
 * このクラス内では、ORBのみが使用可能としている。必要であれば、SIFT, SURFを使えるように拡張して下さい。
 * */
public class CVFeatureDetector {

	private static final String 		TAG 			= "CVFeatureDetector";
	private static final String			LOG_EXEC_DETECT	= "execFeatureDetect: ";
	private static final String			LOG_NATIVE		= "native process";
	private static final String			LOG_JAVA		= "JAVA process";
	private static final String			LOG_RELEASE 	= "release";	
	private static final String 		LOG_IMG_NULL 	= "src or dst image is null. not exec Feature Detect";
	public static final int 			FEATURE_ORB  	= FeatureDetector.ORB;
	
	private FeatureDetector 			mFeatureDetector;
	//private DescriptorExtractor 		mFeatureExtractor;
	private MatOfKeyPoint 				mKeyPoint;
	private Mat							mDescripters;
	
	/**
	 * MoverioでSeeThroughを実現する際には、必要な領域以外の画素は輝度を0とする <br>
	 * そのためのMat型変数
	 * */
	private Mat							mBlackImg;
	private int 						mThreshold 	= 100; 			//初期値
	private int 						mFeature 	= FEATURE_ORB; 	//初期値
	private int 						mCameraWidth;
	private int							mCameraHeight;

	private List<Integer>				mSupportedFeatureDetectMethods;
	
	//native method
	private static native void initNativeFeatureDetect(int width, int heght, int feature, int threshold);
	private static native void releaseNativeFeatureDetect();
	private static native void execNativeFeatureDetect(long srcImage, long dstImage, boolean isBlackback);

	
	/**
	 * 引数なしコンストラクタ <br>
	 * @param feature 	初期設定時に実行したい特徴点抽出手法
	 * @param threshold	初期設定時に設定したい特徴量抽出に使用するしきい値 (今回は不使用)
	 * */
	public CVFeatureDetector(int camera_width, int camera_height, int feature, int threshold) {
		Log.i(TAG, getClass().getSimpleName());
		
		mCameraWidth  = camera_width;
		mCameraHeight = camera_height;
		mBlackImg = Mat.zeros(camera_height, camera_width, CvType.CV_8UC3);
		
		//Javaで実行するようの初期化
		mSupportedFeatureDetectMethods = new ArrayList<Integer>();
		mSupportedFeatureDetectMethods.add(FEATURE_ORB);

		mKeyPoint = new MatOfKeyPoint();

		changeFeatureDetectMethod(feature);
		changeFeatureDetectThreshold(threshold);
		
		//nativeで実行するようの初期化
		initNativeFeatureDetect(mCameraWidth, mCameraHeight, mFeature, mThreshold);
	}
	
	/**
	 * @return サポートしている特徴量検出手法をListで返す。<br>
	 * */
	public List<Integer> getSupportedFeatureDetectMethod() {
		return mSupportedFeatureDetectMethods;
	}
	
	/**
	 * TODO 本来はthresholdのサポート範囲も取れるようにするのがよいが今回ORBしか使えないのでstub実装のみ <p>
	 * 
	 * @param feature 実行したい特徴点点抽出手法
 	 * @return しきい値の最大値、最小値をリスト
	 * */
	public List<Integer> getSupportedThresholdMaxMinVals(int feature) {
		List<Integer> supThvals = new ArrayList<Integer>();
		supThvals = null;
		return supThvals;
	}
	
	/**
	 * {@link #getSupportedFeatureDetectMethod}で返される値から選んで引数にする
	 * @param feature 設定したい特徴点抽出手法 
	 * */
	public void changeFeatureDetectMethod(int feature) {
		mFeature 			= feature;
		mFeatureDetector 	= FeatureDetector.create(mFeature);
		//mFeatureExtractor 	= DescriptorExtractor.create(mFeature);
	}
	
	/**
	 * @param threshold 設定したい特徴点抽出手法に使用するしきい値 <br>
	 * */
	public void changeFeatureDetectThreshold(int threshold) {
		mThreshold = threshold;
	}
	
	/**
	 * @return 現在設定されている特徴点抽出手法
	 * */
	public int getFeatureDetectMethod() {
		return mFeature;
	}
	
	/**
	 * @return 現在設定されている特徴点抽出手法で用いるしきい値
	 * */
	public int getFeatureDetectThreshold() {
		return mThreshold;
	}
	
	/**
	 * インスタンスを解放する際に必ず実行する <br>
	 * コンストラクタとセット
	 * */
	public void release() {
		Log.i(TAG, LOG_RELEASE);
		
		//Java
		if(mKeyPoint != null) {
			mKeyPoint.release();
		}
		if(mDescripters != null) {
			mDescripters.release();
		}
		//native method実行
		releaseNativeFeatureDetect();
	}

	/**
	 * TODO src, dstのMatの大きさが揃っている前提なので違ったらエラーかExceptionさせる <p>
	 * 特徴点抽出を実行して、描画を行う
	 * 
	 * @param srcGrayImg	特徴点を抽出するための入力グレー画像
	 * @param dstColorImg	抽出した特徴点を描画するためのカラー画像
	 * @param isNative		native(C++)で実行するか、javaで実行するか
	 * */
	public void execFeatureDetect(Mat srcGrayImg, Mat dstColorImg, boolean isNative, boolean isBlackBack) {
		if(srcGrayImg == null || dstColorImg == null) {
			Log.e(TAG, LOG_IMG_NULL);
			return;
		}
		if(isNative) {
			//native method実行
			//Log.i(TAG, LOG_EXEC_DETECT+LOG_NATIVE);
			execNativeFeatureDetect(srcGrayImg.getNativeObjAddr(), dstColorImg.getNativeObjAddr(), isBlackBack);
		} else {
			//Log.i(TAG, LOG_EXEC_DETECT+LOG_JAVA);
			if(mDescripters == null) {
				mDescripters = new Mat(dstColorImg.rows(), dstColorImg.cols(), dstColorImg.type());
			}
			mFeatureDetector.detect(srcGrayImg, mKeyPoint);
			//mFeatureExtractor.compute(srcGrayImg, mKeyPoint, mDescripters);
			if(isBlackBack) {
				Features2d.drawKeypoints(mBlackImg, mKeyPoint, dstColorImg);				
			} else {
				Features2d.drawKeypoints(srcGrayImg, mKeyPoint, dstColorImg);								
			}
		}
	}
	
}
