package moverio.opencv.sample.app;

/**
 * FPS計算用のクラス <br>
 * {@link org.opencv.android.JavaCameraView} のXMLオプションopencv:show_fpsをtrue
 * にした時に画面左上に表示されている値とずれているので、計算方法が異なるぽい。。<p>
 * 
 * XMLオプションopencv:show_fpsは res/layout/activity_main.xml に記載がある
 * */
public class CVFpsController {
	private long    basetime;   //測定基準時間
	private int     count;      //フレーム数
	private float   framerate;  //フレームレート
	private String 	format = "%.2f";
	
	public CVFpsController() {
		initFrameRate();
	}
	
	/**
	 * 初期化時に実行
	 * */
	public void initFrameRate() {
		//基準時間をセット
		basetime = System.currentTimeMillis();  		
	}
	
	/**
	 * @return 最新のfps値をfloat型で返す
	 * */
	public float getFrameRate() {
		return framerate;
	}
	
	/**
	 * @return 最新のfps値をString型で返す(小数点以下は二桁)
	 * */
	public String getFrameRateText() {
		String fpstxt = String.format(format, framerate);
		return fpstxt;
	}

	/**
	 * fpsを計算する<p>
	 * カメラスレッドからframeが返されたら実行する. <br>
	 * {@link MoverioOpenCVApp#onCameraFrame()} 
	 * */
	public void count() {
		//フレーム数をインクリメント
		++count; 

		//現在時刻を取得
		long now = System.currentTimeMillis();
		//１秒以上経過していれば
		if (now - basetime >= 1000) {       
			framerate = (float)(count * 1000) / (float)(now - basetime);
			//現在時刻を基準時間に
			basetime = now;     
			//フレーム数をリセット
			count = 0;         
		}
	}
}
