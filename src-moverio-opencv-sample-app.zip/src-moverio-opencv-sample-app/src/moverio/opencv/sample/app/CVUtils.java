package moverio.opencv.sample.app;

import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import android.util.Log;

/**
 * 座標移動や画像縮小を行うためのUtilクラス<p>
 * 
 * TODO 
 * 倍率はx0.1刻みで変更できるような仕組みを作りたい <br>
 * 約2mくらいの距離でチューニングした初期値 <br>
 * Moverioのカメラ画素数がVGA640px*480pxなので
 * 拡大率が3.2倍になるようにチューニングをすると200px*150pxの解像度になる
 */
public class CVUtils {

	private static final String 	TAG 					= "CVUtils";
	private static final String		LOG_RESIZE_FRAME		= "resizeCameraInputFrameForMoverioSeeThrough";
	private static final String 	LOG_INVALID_FUNC_ARGS 	= "Invalid arguments";
	private static final String 	LOG_MAT_SIZE_NOT_MATCH	= "Mat size not match";
	
	private Mat 					mWorkMat;
	
	public CVUtils() {
		mWorkMat  = new Mat();
	}
	
	/**
	 * インスタンス解放時に必ず呼ぶ
	 * */
	public void release() {
		mWorkMat.release();
	}
	
	/**
	 * TODO 今回使用しないので、本実装していない <p>
	 * 指定された移動量と倍率で座標変換を行う <br>
	 * 
	 * @param src_pt 	変換させたい座標 
	 * @param trans_pt 	移動させたい座標量
	 * @param scale 	拡大率
	 * */
	public CVPoint2D adjustCoordinatesForMoverioSeeThorogh (
			CVPoint2D src_pt, CVPoint2D trans_pt, long scale) {
		CVPoint2D ret2D = new CVPoint2D();
		//TODO 仕様を決めて実装
		return ret2D;
	}

	/**
	 * 指定した倍率と範囲で画像を切り出す <br>
	 * 注意1：早いけど倍率が3.2倍とか約数でしか処理できない <br>
	 * 注意2：TODO src, dstのMatの大きさが揃っている前提なので違ったらエラーかExceptionさせる
	 * 今はnull時のみエラーログだしている
	 * 
	 * @param src 		入力画像を格納したMat
	 * @param dst 		出力画像格納したMat
	 * @param scale 	拡大倍率 
	 * @param start_pt 	切り出し開始座標
	 * */
	public void resizeCameraInputFrameForMoverioSeeThrough (
			Mat src, Mat dst, double scale, CVPoint2D start_pt) {

		//Log.i(TAG, LOG_RESIZE_FRAME);
		if(src == null || dst == null || scale <= 0 || start_pt == null) {
			Log.e(TAG, LOG_INVALID_FUNC_ARGS);
			return;
		}
		
//		if(src.size() != dst.size()) {
//			Log.e(TAG, LOG_MAT_SIZE_NOT_MATCH);			
//			return;
//		}
		
		src.submat(
				start_pt.getY(), start_pt.getY() + (int)((double)dst.height()/scale), 
				start_pt.getX(), start_pt.getX() + (int)((double)dst.width()/scale)	
				).copyTo(mWorkMat);

		Imgproc.resize(mWorkMat, dst, new Size(), 
				scale, scale, Imgproc.INTER_LINEAR);//INTER_CUBICは低速らしい
	}

	/**
	 * 指定した倍率と範囲で画像を切り出す <br>
	 * 注意：遅いけど倍率が自由に設定できる <br>
	 * TODO !!実装が未!! 今は{@link #resizeCameraInputFrameForMoverioSeeThrough}を使用
	 * @param src 		入力画像を格納したMat
	 * @param dst 		出力画像格納したMat
	 * @param scale 	拡大倍率 
	 * @param start_pt 	切り出し開始座標
	 * 	 * */
	public void resizeCameraInputFrameForMoverioSeeThrough_ (
			Mat src, Mat dst, double scale, CVPoint2D start_pt) {
//
//		Imgproc.resize(src, mWorkMat, new Size(), 
//				scale, scale, Imgproc.INTER_LINEAR);//INTER_CUBICは低速らしい
//		
//		//TODO 各Matのwidth/heightの比較、違ったら補正するかException
//		mWorkMat.submat(
//				start_pt.getY(), start_pt.getY() + dst.height(), 
//				start_pt.getX(), start_pt.getX() + dst.width() 	
//				).copyTo(dst);
	}

}
