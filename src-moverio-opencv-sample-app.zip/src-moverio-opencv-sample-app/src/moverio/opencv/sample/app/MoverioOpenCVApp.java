package moverio.opencv.sample.app;

import java.util.List;

import moverio.opencv.sample.app.R;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
//import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Button;

////Epson original libs
//import jp.epson.moverio.bt200.DisplayControl;
//import jp.epson.moverio.bt200.AudioControl;
//import jp.epson.moverio.bt200.SensorControl;

public class MoverioOpenCVApp extends Activity implements CvCameraViewListener2 {

	private static final String TAG  				= "MoverioOpenCVApp";
	private static final String OPENCV_LIB_VER 		= OpenCVLoader.OPENCV_VERSION_2_4_9;

	private static final String CV_FEATURE_DETECT	= "FeatDetect";
	private static final String CV_FACE 			= "Face-detect";
	private static final String CV_CANNY 			= "Canny-Edge";
	private static final String CV_ADJUST 			= "Adjust";

	private static final String LIB_NATIVE_JNIS		= "native_method";

	private static final String LOG_ON_MNG			= "onManagerConnected ";
	private static final String LOG_ON_MNG_STATUS 	= LOG_ON_MNG+"status:";
	private static final String LOG_ON_MNG_DEFAULT	= LOG_ON_MNG+"default";
	private static final String LOG_OPNCV_SUCCESS 	= "OpenCV loaded successfully";
	private static final String LOG_ERR_LOADLIB 	= "loadlibrary failed: ";
	
	/**
	 * 下部のナビゲーションバーを非表示にして、カメラ画像を全画面表示にするための定義 <br>
	 * Moverio BT-200開発用資料 BT200_TIW1405CJ.pdf P4.参照 <br>
	 * Developerサイト https://moverio.epson.biz/jsp/developer/dev_nd-014.jsp
	 * */
	private static final int 	FULL_SCREEN 		= 0x80000000;

	//タイトルバーの表示/非表示
	private static final boolean sIsNoTitle 		= true;

	//全画面表示
	private static final boolean sIsfullscreen		= true;

	private String[] 		process_items 			
	= {CV_ADJUST, CV_CANNY, CV_FEATURE_DETECT ,CV_FACE};
	private String 			mProcessName 			= process_items[0];

	private boolean 		mIsLibNativeLoadSuccess = false;

	private Context 		mContext;

	private Mat 			mGrayImg;
	private Mat 			mRgbaImg;

	private Button 			mUpbtn;
	private Button 			mDownbtn;
	private Button 			mLeftbtn;
	private Button 			mRightbtn;

	private Button 			mAdjustbtn;
	private Button 			mCannybtn;
	private Button 			mFeaturebtn;
	private Button 			mFacebtn;
	private Button 			mBlackBackbtn;
	private Button 			mNativebtn;
	private TextView		mProcessNameTxt;
	private TextView		mInitTextView;
	private TextView		mfpsTextView;
	
	/**
	 * TODO 倍率はx0.1刻みで変更できるような仕組みを作りたい
	 * 約2mくらいの距離でチューニングした初期値
	 * Moverioのカメラ画素数がVGA640px*480pxなので
	 * 拡大率が3.2倍になるようにチューニングをすると200px*150pxの解像度になる
	 */
	private static final double RESIZE_RATE = 3.2;
	private static final int 	STEP_X  = 4;
	private static final int 	STEP_Y  = 3;
	private CVPoint2D			mTrans2D;
	private int					mTrans_x = 176; //44*4
	private int 				mTrans_y = 126;	//42*3
	private int 				mCameraWidth;
	private int 				mCameraHeight;

	/**
	 * 背景を黒色にするか否か.<br>
	 * trueであればMoverioでシースルーで見るためのモードになる。
	 * */
	private boolean				mIsBlackBack = true;

	private static final 		String BACK_BLACK  	= "BlackBack";
	private static final 		String BACK_CAMERA 	= "CameraBack";

	/**
	 * 処理をNativeでするか否か.<br>
	 * */	
	private boolean 			mIsNativeMethod_featureDetect = true;

	private static final 		String NATIVE_ON 	= "Native";
	private static final 		String NATIVE_OFF 	= "Non-Native";

	/** 
	 * カメラビューのインスタンス
	 * CameraBridgeViewBase は JavaCameraView/NativeCameraView のスーパークラス
	 */
	private CameraBridgeViewBase 	mCameraView;
	
	private CVUtils 				mUtils;
	private CVFaceDetector 			mFaceDetector;
	private CVFeatureDetector 		mFeatureDetector;
	private int 					mFeatureThreshold;
	private int 					mFeatureDetect_Method;
	private List<Integer> 			mSupportedfeatureDetectMethods;
	
	private static final String 	FPS = " fps";
	private CVFpsController			mFpsContorller;
	private Handler 				mhandler;
	private Runnable 				mFpsRunnable;
	

	/**
	 *  ライブラリ初期化完了後に呼ばれるコールバック (onManagerConnected) <br>
	 * 	public abstract class BaseLoaderCallback implements LoaderCallbackInterface
	 */
	private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
		@Override
		public void onManagerConnected(int status) {
			Log.i(TAG, LOG_ON_MNG_STATUS+status);
			switch (status) {
			// 読み込みが成功したらカメラプレビューを開始
			case LoaderCallbackInterface.SUCCESS: {
				Log.i(TAG, LOG_OPNCV_SUCCESS);
				mCameraView.enableView();
			} break;
			default: {
				super.onManagerConnected(status);
				Log.i(TAG, LOG_ON_MNG_DEFAULT);
			} break;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.i(TAG, getClass().getSimpleName());
		super.onCreate(savedInstanceState);
		mContext = this;

		if(sIsNoTitle) {
			requestWindowFeature(Window.FEATURE_NO_TITLE);
		}		
		if(sIsfullscreen) {
			Window win = getWindow();
			WindowManager.LayoutParams winParams = win.getAttributes();
			winParams.flags |= FULL_SCREEN;
			win.setAttributes(winParams);     
		}		
		setContentView(R.layout.activity_main);
		initCameraView();
		mInitTextView 	= (TextView)findViewById(R.id.init_jni_text);	
		mProcessNameTxt = (TextView)findViewById(R.id.process_name);
		mfpsTextView	= (TextView)findViewById(R.id.fps_text);
		mUpbtn 			= (Button)findViewById(R.id.up_btn);
		mDownbtn 		= (Button)findViewById(R.id.down_btn);
		mLeftbtn 		= (Button)findViewById(R.id.left_btn);
		mRightbtn 		= (Button)findViewById(R.id.right_btn);
		mAdjustbtn 		= (Button)findViewById(R.id.adjust_btn);
		mFacebtn 		= (Button)findViewById(R.id.face_btn);
		mFeaturebtn 	= (Button)findViewById(R.id.feature_btn);
		mCannybtn 		= (Button)findViewById(R.id.canny_btn);
		mBlackBackbtn	= (Button)findViewById(R.id.blackback_btn);
		mNativebtn		= (Button)findViewById(R.id.native_btn);

		setVisibilityAdjustBtns(View.GONE);
		setVisibilityProcessBtns(View.GONE);
		mBlackBackbtn.setVisibility(View.GONE);
		mNativebtn.setVisibility(View.GONE);
	}

	/**
	 * カメラビューのインスタンスを変数にバインドして初期化、リスナーの設定 <br>
	 * */
	private void initCameraView() {		
		mCameraView = (CameraBridgeViewBase) findViewById(R.id.camera_view);
		mCameraView.setCvCameraViewListener(this);
	}

	/**
	 * 原因の根本理解 face-detectを見て、loadlibとebableViewの順を正しくした. <br>
	 * {@link BaseLoaderCallback#onManagerConnected(int)} 内で実行される
	 * {@link CameraBridgeViewBase#enableView()} がsynchronizedなので、
	 * jniのlibを読み込む処理はこの前に実装するのが良さそう.<br>
	 * 後ろに書くとsynchronizedされているので先に実行が走り、何かの同期のタイミングとずれておかしくなっていそう。
	 * */
	private void initNativeJNImethods() {
		try {
			System.loadLibrary(LIB_NATIVE_JNIS);
		} catch ( UnsatisfiedLinkError ue ) {
			Log.e(TAG, LOG_ERR_LOADLIB + LIB_NATIVE_JNIS);
			return;
		}
		mIsLibNativeLoadSuccess = true;
		mFaceDetector = new CVFaceDetector(mContext, mCameraWidth, mCameraHeight);

		mFeatureDetect_Method = CVFeatureDetector.FEATURE_ORB;
		mFeatureDetector = new CVFeatureDetector(
				mCameraWidth, mCameraHeight, mFeatureDetect_Method, mFeatureThreshold);
		mSupportedfeatureDetectMethods = mFeatureDetector.getSupportedFeatureDetectMethod();
		mFeatureDetector.changeFeatureDetectMethod(mSupportedfeatureDetectMethods.get(0).intValue());

		mInitTextView.setText( stringFromJNI() );
		
		mFpsContorller 	= new CVFpsController();
		mhandler		= new Handler();
	}

	/**
	 * 任意の文字列を表示するJNIメソッド
	 * */
	public native String stringFromJNI();	

	@Override
	protected void onResume() {
		super.onResume();
		/* 非同期でライブラリの読み込み/初期化を行う
		 * static boolean initAsync(
		 * 		String Version, 
		 * 		Context AppContext, 
		 * 		LoaderCallbackInterface Callback) */
		OpenCVLoader.initAsync(OPENCV_LIB_VER, this, mLoaderCallback);
	}

	@Override
	protected void onPause() {
		Log.i(TAG, getClass().getSimpleName());
		if (mCameraView != null) {
			mCameraView.disableView();
		}
		super.onPause();
		mhandler = null;
		mFaceDetector.release();
		mFeatureDetector.release();
	}

	@Override
	public void onDestroy() {
		Log.i(TAG, getClass().getSimpleName());
		super.onDestroy();
		if (mCameraView != null) {
			mCameraView.disableView();
		}
	}

	@Override
	public void onCameraViewStarted(int width, int height) {
		Log.i(TAG, getClass().getSimpleName() +": (w,h)=("+width+", "+height+")");
		mCameraWidth = width;
		mCameraHeight = height;

		initNativeJNImethods();
		initAdjustButtons();
		setVisibilityProcessBtns(View.VISIBLE);
		setVisibilityAdjustBtns(View.VISIBLE);
		setVisibilityNativeBtn(View.VISIBLE);
		setVisibilityBlackBackBtn(View.VISIBLE);

		mInitTextView.setVisibility(View.GONE);

		/** 
		 * Mat(int rows, int cols, int type)
		 * rows(行): height, cols(列): width 
		 * */
		mGrayImg = new Mat(height, width, CvType.CV_8UC1);
		 //onCameraFrameの引数で渡される引数がα有りなので4ch
		mRgbaImg = new Mat(height, width, CvType.CV_8UC4);
		mUtils 	 = new CVUtils();
		mTrans2D = new CVPoint2D(mTrans_x, mTrans_y);
	}

	@Override
	public void onCameraViewStopped() {
		Log.i(TAG, getClass().getSimpleName());
		mGrayImg.release();
		mRgbaImg.release();
		mUtils.release();
	}

	private class fpsShowRunnable implements Runnable {
		private String mfpstxt;
		
		fpsShowRunnable(String fpstxt) {
			mfpstxt = fpstxt;
		}
		@Override
		public void run() {
			mfpstxt = mfpstxt+FPS;
			mfpsTextView.setText(mfpstxt);
		}		
	}
	
	@Override
	public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
		 //TODO 高速化, リサイズの順番とか頑張るところ

		//fps計算
		mFpsContorller.count();
		String fps = mFpsContorller.getFrameRateText();
		
		//fps表示更新
		mhandler.post(new fpsShowRunnable(fps));
		
		if(CV_CANNY.equals(mProcessName)) {
			//TODO 決め打ちになっているので、可能であればスライダーで変更など
			Imgproc.Canny(inputFrame.gray(), mGrayImg, 80, 100); 
			//Core.bitwise_not(mOutputFrame, mOutputFrame);
			mUtils.resizeCameraInputFrameForMoverioSeeThrough(
					mGrayImg, mGrayImg, RESIZE_RATE, mTrans2D);
			return mGrayImg;

		} else if(CV_FEATURE_DETECT.equals(mProcessName)) {
			if(mIsBlackBack) {
				mRgbaImg = Mat.zeros(inputFrame.rgba().rows(), 
						inputFrame.rgba().cols(), inputFrame.rgba().type());
			} else {
				inputFrame.rgba().copyTo(mRgbaImg);
			}
			mFeatureDetector.execFeatureDetect(
					inputFrame.gray(), mRgbaImg, 
					mIsNativeMethod_featureDetect, mIsBlackBack);
			mUtils.resizeCameraInputFrameForMoverioSeeThrough(
					mRgbaImg, mRgbaImg, RESIZE_RATE, mTrans2D);				
			return mRgbaImg;       		

		} else if(CV_FACE.equals(mProcessName)) {
			if(mIsBlackBack) {
				mRgbaImg = Mat.zeros(inputFrame.rgba().rows(), 
						inputFrame.rgba().cols(), inputFrame.rgba().type());
			} else {
				inputFrame.rgba().copyTo(mRgbaImg);
			}
			mFaceDetector.execFaceDetection(inputFrame.gray(), mRgbaImg);
			mUtils.resizeCameraInputFrameForMoverioSeeThrough(
					mRgbaImg, mRgbaImg, RESIZE_RATE, mTrans2D);
			return mRgbaImg;

		} else if(CV_ADJUST.equals(mProcessName)){
			mUtils.resizeCameraInputFrameForMoverioSeeThrough(
					inputFrame.rgba(), mRgbaImg, RESIZE_RATE, mTrans2D);
			return mRgbaImg;

		} else {
			return inputFrame.rgba();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return false;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		return false;
	}

	private static final int ZERO 	= 0;
	private int mUsingArea_width 	= 200; 	//TODO 動的に計算する
	private int mUsingArea_height 	= 150;	//TODO 動的に計算する

	/**
	 * 各ボタンにリスナーを登録する
	 * */
	private void initAdjustButtons() {		
		mUpbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mTrans_y += STEP_Y;
				if(mTrans_y < ZERO) {
					mTrans_y = ZERO;
				} else if(mTrans_y > mCameraHeight-mUsingArea_height) {
					mTrans_y = mCameraHeight - (mUsingArea_height + STEP_Y);
				}
				mTrans2D.setY(mTrans_y);
			}
		});

		mDownbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mTrans_y -= STEP_Y;
				if(mTrans_y < ZERO) {
					mTrans_y = ZERO;
				} else if(mTrans_y > mCameraHeight-mUsingArea_height) {
					mTrans_y = mCameraHeight - (mUsingArea_height + STEP_Y);
				}
				mTrans2D.setY(mTrans_y);
			}
		});

		mLeftbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mTrans_x += STEP_X;
				if(mTrans_x < ZERO) {
					mTrans_x = ZERO;
				} else if(mTrans_x > mCameraWidth-mUsingArea_width) {
					mTrans_x = mCameraWidth - (mUsingArea_width + STEP_X);
				}
				mTrans2D.setX(mTrans_x);
			}
		});

		mRightbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mTrans_x -= STEP_X;
				if(mTrans_x < ZERO) {
					mTrans_x = ZERO;
				} else if(mTrans_x > mCameraWidth-mUsingArea_width) {
					mTrans_x = mCameraWidth - (mUsingArea_width + STEP_X);
				}
				mTrans2D.setX(mTrans_x);
			}
		});

		mAdjustbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mProcessName = CV_ADJUST;
				mProcessNameTxt.setText(mProcessName);
				setVisibilityAdjustBtns(View.VISIBLE);
				setVisibilityNativeBtn(View.GONE);
				setVisibilityBlackBackBtn(View.GONE);
			}
		});

		mFacebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mProcessName = CV_FACE;
				mProcessNameTxt.setText(mProcessName);
				setVisibilityAdjustBtns(View.GONE);
				setVisibilityNativeBtn(View.GONE);
				setVisibilityBlackBackBtn(View.VISIBLE);
			}
		});
		mFeaturebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mProcessName = CV_FEATURE_DETECT;
				mProcessNameTxt.setText(mProcessName);
				setVisibilityAdjustBtns(View.GONE);
				setVisibilityNativeBtn(View.VISIBLE);
				setVisibilityBlackBackBtn(View.VISIBLE);
			}
		});
		mCannybtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mProcessName = CV_CANNY;
				mProcessNameTxt.setText(mProcessName);
				setVisibilityAdjustBtns(View.GONE);
				setVisibilityNativeBtn(View.GONE);
				setVisibilityBlackBackBtn(View.GONE);
			}
		});
		mBlackBackbtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mIsBlackBack = !mIsBlackBack;
				if(mIsBlackBack){
					mBlackBackbtn.setText(BACK_CAMERA);
				} else {
					mBlackBackbtn.setText(BACK_BLACK);					
				}
			}
		});
		mNativebtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				mIsNativeMethod_featureDetect = !mIsNativeMethod_featureDetect;
				if(mIsNativeMethod_featureDetect){
					mNativebtn.setText(NATIVE_OFF);
				} else {
					mNativebtn.setText(NATIVE_ON);					
				}
			}
		});	
	}

	/**
	 * 画面の縦横方向を変更するボタンの表示制御
	 * @param visibility {@link View#VISIBLE}または、{@link View#GONE}
	 * */
	private void setVisibilityAdjustBtns(int visibility) {
		if(CV_ADJUST.equals(mProcessName)) {
			mUpbtn.setVisibility(visibility);
			mDownbtn.setVisibility(visibility);
			mLeftbtn.setVisibility(visibility);
			mRightbtn.setVisibility(visibility);
		} else {
			mUpbtn.setVisibility(View.GONE);
			mDownbtn.setVisibility(View.GONE);
			mLeftbtn.setVisibility(View.GONE);
			mRightbtn.setVisibility(View.GONE);			
		}
	}

	/**
	 * 処理を変更するボタンの表示制御
	 * @param visibility {@link View#VISIBLE}または、{@link View#GONE}
	 * */
	private void setVisibilityProcessBtns(int visibility) {	
		mAdjustbtn.setVisibility(visibility);
		mFacebtn.setVisibility(visibility);
		mFeaturebtn.setVisibility(visibility);
		mCannybtn.setVisibility(visibility);
		mProcessNameTxt.setVisibility(visibility);
		mfpsTextView.setVisibility(visibility);
	}

	/**
	 * Native/Java処理の切替をするボタンの表示制御 <br>
	 * 特徴点検出以外の時は常に非表示になる
	 * @param visibility {@link View#VISIBLE}または、{@link View#GONE}
	 * */
	private void setVisibilityNativeBtn(int visibility) {
		if(CV_FEATURE_DETECT.equals(mProcessName)) {
			mNativebtn.setVisibility(visibility);
		} else {
			mNativebtn.setVisibility(View.GONE);
		}
	}

	/**
	 * 背景画を黒/カメラ出力で切替をするボタンの表示制御 <br>
	 * 顔検出、特徴点検出以外の時は常に非表示になる
	 * @param visibility {@link View#VISIBLE}または、{@link View#GONE}
	 * */
	private void setVisibilityBlackBackBtn(int visibility) {
		if(CV_FACE.equals(mProcessName) 
				|| CV_FEATURE_DETECT.equals(mProcessName)) {
			mBlackBackbtn.setVisibility(visibility);
		} else {
			mBlackBackbtn.setVisibility(View.GONE);
		}
	}
}
